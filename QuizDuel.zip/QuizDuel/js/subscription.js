function buySubscription(months) {
  const prices = {1: 499, 3: 1299};
  const days = months * 30;
  const expiry = Date.now() + (days * 24 * 60 * 60 * 1000);
  
  localStorage.setItem('subscription', JSON.stringify({
    months,
    price: prices[months],
    expiry
  }));
  
  alert(`🎉 Подписка на ${months} месяц(а) успешно оформлена!\nДоступ до ${new Date(expiry).toLocaleDateString()}\nТеперь все уроки открыты!`);
  window.location.href = 'index.html'; // или назад на главную
}